<script setup>
import { ICON_HEART } from '../utils/icons'
import CategoryIcon from './CategoryIcon.vue'

const props = defineProps({
  product: {
    type: Object,
    required: true,
  },

  // 是否已经收藏
  isFavorite: {
    type: Boolean,
    default: false,
  },
})

const emit = defineEmits(['open', 'toggle-fav'])

const heartMarkup = `<svg viewBox="0 0 24 24" fill="none">${ICON_HEART}</svg>`

// 点击收藏
function onToggleFav(evt) {
  // 防止点击爱心时触发商品卡片的点击事件
  evt.stopPropagation()

  emit('toggle-fav', props.product.id)
}

// 点击商品
function onOpen() {
  emit('open', props.product.id)
}
</script>

<template>
  <div
    class="card"
    @click="onOpen"
  >
    <!-- 商品图片 -->
    <div class="card-media">
      <img
        v-if="product.images && product.images.length > 0"
        :src="product.images[0]"
        :alt="product.name"
        class="product-image"
      />

      <!-- 没有图片时显示分类图标 -->
      <CategoryIcon
        v-else
        :category="product.category"
      />

      <!-- 已售出 -->
      <span
        v-if="product.status === 'sold'"
        class="card-status"
      >
        已售出
      </span>

      <!-- 收藏按钮 -->
      <button
        class="fav-btn"
        :class="{ active: isFavorite }"
        type="button"
        aria-label="收藏商品"
        @click="onToggleFav"
        v-html="heartMarkup"
      ></button>
    </div>

    <!-- 商品信息 -->
    <div class="card-body">
      <p class="card-title">
        {{ product.name }}
      </p>

      <div class="card-price-row">
        <span class="card-price">
          ¥{{ product.price }}
        </span>

        <span
          v-if="product.originalPrice"
          class="card-original"
        >
          ¥{{ product.originalPrice }}
        </span>
      </div>

      <div class="card-meta">
        <span>
          {{ product.campus || '未知校区' }}
        </span>

        <span>
          {{ product.createdAt || '' }}
        </span>
      </div>
    </div>
  </div>
</template>

<style scoped>
.card {
  position: relative;
  overflow: hidden;
  cursor: pointer;
}

.card-media {
  position: relative;
  width: 100%;
  height: 220px;
  overflow: hidden;
  border-radius: 12px;
}

.product-image {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: cover;
}

.product-image:not([src]) {
  display: none;
}

/* 已售出标签 */
.card-status {
  position: absolute;
  top: 10px;
  left: 10px;

  padding: 4px 8px;

  border-radius: 6px;

  background: rgba(0, 0, 0, 0.65);
  color: #fff;

  font-size: 12px;
}

/* =========================
   收藏按钮
   ========================= */

.fav-btn {
  position: absolute;
  top: 10px;
  right: 10px;

  width: 36px;
  height: 36px;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 0;

  border: none;
  border-radius: 50%;

  /*
   * 深色半透明背景
   *
   * 这样：
   * 未收藏 = 白色爱心 + 深色背景
   * 已收藏 = 红色爱心 + 深色背景
   */
  background: rgba(0, 0, 0, 0.55);

  cursor: pointer;

  /* 阴影，让按钮和商品图片分离 */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);

  transition:
    background 0.2s ease,
    transform 0.2s ease;
}

/* 鼠标移动到收藏按钮 */
.fav-btn:hover {
  background: rgba(0, 0, 0, 0.7);

  transform: scale(1.08);
}

/* SVG 大小 */
.fav-btn :deep(svg) {
  width: 20px;
  height: 20px;

  display: block;

  transition:
    fill 0.2s ease,
    stroke 0.2s ease,
    transform 0.2s ease;
}

/* =========================
   未收藏
   ========================= */

/*
 * 未收藏：
 * 白色爱心
 */
.fav-btn:not(.active) :deep(svg *) {
  stroke: #ffffff;
}

/* =========================
   已收藏
   ========================= */

/*
 * 已收藏：
 * 红色爱心
 */
.fav-btn.active :deep(svg *) {
  stroke: #ff3b30;
  fill: #ff3b30;
}

/* 已收藏时爱心稍微放大 */
.fav-btn.active :deep(svg) {
  transform: scale(1.05);
}

/* =========================
   商品内容
   ========================= */

.card-body {
  padding: 12px 2px;
}

.card-title {
  margin: 0 0 8px;

  font-size: 15px;
  font-weight: 500;

  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.card-price-row {
  display: flex;
  align-items: center;

  gap: 8px;
}

.card-price {
  font-size: 18px;
  font-weight: 700;
}

.card-original {
  font-size: 13px;
  text-decoration: line-through;
  opacity: 0.55;
}

.card-meta {
  display: flex;
  justify-content: space-between;

  margin-top: 8px;

  font-size: 12px;
  opacity: 0.6;
}
</style>