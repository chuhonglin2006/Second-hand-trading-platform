<script setup>
import { reactive, ref, onUnmounted } from 'vue'
import { useRouter } from 'vue-router'
import { useUserStore } from '../stores/user'
import { useMarketStore } from '../stores/market'
import { useToast } from '../composables/useToast'
import { authApi } from '../api/auth'

const router = useRouter()
const userStore = useUserStore()
const marketStore = useMarketStore()
const { show } = useToast()

const mode = ref('login')

const form = reactive({
  username: '',
  studentId: '',
  email: '',
  code: '',
  password: '',
})

const error = ref('')
const countdown = ref(0)
const submitting = ref(false)
const sendingCode = ref(false)

let countdownTimer = null


// ==============================
// 重置表单
// ==============================

function resetForm() {
  Object.assign(form, {
    username: '',
    studentId: '',
    email: '',
    code: '',
    password: '',
  })

  error.value = ''
}


// ==============================
// 切换登录 / 注册
// ==============================

function switchMode(newMode) {
  mode.value = newMode
  resetForm()
}


// ==============================
// 发送验证码
// ==============================

async function sendCode() {
  if (sendingCode.value || countdown.value > 0) {
    return
  }

  if (!form.email || !form.email.includes('@')) {
    error.value = '请输入正确的邮箱地址'
    return
  }

  error.value = ''
  sendingCode.value = true

  try {
    const result = await authApi.sendCode(form.email)

    console.log('验证码发送结果:', result)

    countdown.value = 60

    if (countdownTimer) {
      clearInterval(countdownTimer)
    }

    countdownTimer = setInterval(() => {
      countdown.value -= 1

      if (countdown.value <= 0) {
        countdown.value = 0
        clearInterval(countdownTimer)
        countdownTimer = null
      }
    }, 1000)

    show(result.message || '验证码发送成功')

  } catch (err) {
    console.error('发送验证码失败:', err)

    error.value =
      err.response?.data?.detail ||
      '验证码发送失败，请稍后重试'

  } finally {
    sendingCode.value = false
  }
}


// ==============================
// 提交表单
// ==============================

async function submit() {
  if (submitting.value) {
    return
  }

  error.value = ''


  // ==========================
  // 注册
  // ==========================

  if (mode.value === 'register') {

    if (
      !form.username ||
      !form.studentId ||
      !form.email ||
      !form.password
    ) {
      error.value = '请完整填写注册信息（学号为必填项）'
      return
    }

    if (!form.code || form.code.length !== 6) {
      error.value = '请输入6位邮箱验证码'
      return
    }

    if (form.password.length < 6) {
      error.value = '密码至少需要6位'
      return
    }

    submitting.value = true

    try {
      const result = await authApi.register({
        username: form.username,
        student_id: form.studentId,
        email: form.email,
        password: form.password,
        code: form.code,
      })

      console.log('注册成功:', result)

      // 后端返回 access_token
      if (!result.access_token) {
        throw new Error('服务器没有返回登录 Token')
      }

      // 保存 Token
      await userStore.register(result)
      await marketStore.fetchFavorites()

      show(result.message || '注册成功，欢迎加入')

      resetForm()

      await router.push({
        name: 'home',
      })

    } catch (err) {
      console.error('注册失败:', err)

      error.value =
        err.response?.data?.detail ||
        err.message ||
        '注册失败，请稍后重试'

    } finally {
      submitting.value = false
    }

    return
  }


  // ==========================
  // 登录
  // ==========================

  if (!form.email || !form.email.includes('@')) {
    error.value = '请输入正确的邮箱地址'
    return
  }

  if (!form.password) {
    error.value = '请输入密码'
    return
  }

  submitting.value = true

  try {
    const result = await authApi.login({
      user_email: form.email,
      password: form.password,
    })

    console.log('登录接口返回:', result)

    // 你的后端返回的是 access_token
    if (!result.access_token) {
      throw new Error('服务器没有返回登录 Token')
    }

    // 保存 Token
    await userStore.login(result)
    await marketStore.fetchFavorites()

    show(result.message || '登录成功')

    resetForm()

    await router.push({
      name: 'home',
    })

  } catch (err) {
    console.error('登录失败:', err)

    error.value =
      err.response?.data?.detail ||
      err.message ||
      '邮箱或密码错误'

  } finally {
    submitting.value = false
  }
}


// ==============================
// 组件销毁
// ==============================

onUnmounted(() => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
    countdownTimer = null
  }
})
</script>


<template>
  <div class="auth-wrap">
    <div class="auth-card">

      <h1 class="auth-title">
        {{ mode === 'login' ? '欢迎回来' : '注册账号' }}
      </h1>

      <p class="auth-sub">
        {{
          mode === 'login'
            ? '登录后继续查看'
            : '用邮箱注册，专属个人二手商品展示'
        }}
      </p>


      <!-- 错误提示 -->
      <div
        v-if="error"
        class="form-error"
      >
        {{ error }}
      </div>


      <!-- 用户名 -->
      <div
        v-if="mode === 'register'"
        class="field"
      >
        <label>用户名</label>

        <input
          v-model="form.username"
          placeholder="给自己起个名字（不可重复）"
          maxlength="50"
        />
      </div>


      <!-- 学号 -->
      <div
        v-if="mode === 'register'"
        class="field"
      >
        <label>
          学号
          <span style="color: var(--muted-2)">
            （必填）
          </span>
        </label>

        <input
          v-model="form.studentId"
          placeholder="请输入你的学号"
          maxlength="30"
        />
      </div>


      <!-- 邮箱 -->
      <div class="field">
        <label>邮箱</label>

        <input
          v-model="form.email"
          type="email"
          placeholder="you@campus.edu.cn"
        />
      </div>


      <!-- 验证码 -->
      <div
        v-if="mode === 'register'"
        class="field"
      >
        <label>邮箱验证码</label>

        <div class="code-row">

          <input
            v-model="form.code"
            placeholder="6位数字"
            maxlength="6"
            inputmode="numeric"
          />

          <button
            class="code-btn"
            :disabled="
              countdown > 0 ||
              sendingCode
            "
            @click="sendCode"
          >
            {{
              countdown > 0
                ? countdown + 's后重发'
                : sendingCode
                  ? '发送中...'
                  : '发送验证码'
            }}
          </button>

        </div>
      </div>


      <!-- 密码 -->
      <div class="field">
        <label>密码</label>

        <input
          v-model="form.password"
          type="password"
          placeholder="至少6位"
          minlength="6"
        />
      </div>


      <!-- 登录 / 注册 -->
      <button
        class="btn btn-primary btn-block"
        :disabled="submitting"
        @click="submit"
      >
        {{
          submitting
            ? '处理中...'
            : mode === 'login'
              ? '登录'
              : '注册'
        }}
      </button>


      <!-- 切换 -->
      <div class="auth-switch">

        <template v-if="mode === 'login'">

          还没有账号？

          <button
            @click="switchMode('register')"
          >
            立即注册
          </button>

        </template>

        <template v-else>

          已有账号？

          <button
            @click="switchMode('login')"
          >
            直接登录
          </button>

        </template>

      </div>

    </div>
  </div>
</template>