"""商品接口"""
from typing import Any
from crud_1.produces import get_products_list,get_produce_info,publish_produce,search_product,get_my_products,\
favorite_produce,unfavorite_produce,get_my_favorite,get_products_category,get_others_products,delete_my_product,\
change_my_product,mark_as_sold,get_my_product_info
from fastapi import APIRouter,Query,Form,Depends,File,UploadFile
from decimal import Decimal
from crud_1.users import get_user_info,get_optional_user_info
from schemas_1.products import ProductUpdate

products = APIRouter()


"""获取商品列表接口"""
@products.get("/api/products")
async def get_products(page:int = Query(1,ge=1),page_size:int = Query(20,ge=1,le=100)) -> dict[str, Any]:
    result = await get_products_list(page = page,page_size = page_size)
    return result

"""搜索商品接口"""
@products.get("/api/products/search")
async def search_products(product_name:str = Query(...)) -> dict[str, Any]:
    result = await search_product(product_name)
    return result

"""获取商品分类接口"""
@products.get("/api/products/categories")
async def produces_categories() -> dict[str,Any]:
    result = await get_products_category()
    return result

"""获取商品详细信息接口"""
@products.get("/api/products/{product_id}")
async def get_produce(product_id:int,current_user = Depends(get_optional_user_info)) -> dict[str, Any]:
    result = await get_produce_info(
        product_id=product_id,
        viewer_id=current_user["id"] if current_user else None
    )
    return result

"""获取本人商品详细信息接口"""
@products.get("/api/my/products/{product_id}")
async def get_my_produce(product_id:int,current_user = Depends(get_user_info)) -> dict[str, Any]:
    result = await get_my_product_info(
        user_id=current_user["id"],
        product_id=product_id
    )
    return result

"""发布商品接口"""
@products.post("/api/products")
async def publish_product(product_name:str = Form(...),
                        price:Decimal = Form(...),
                        original_price:Decimal | None = Form(None),
                        description:str = Form(...),
                        category_id:int = Form(...),
                        campus:str = Form(...),
                        images: list[UploadFile] = File(...),
                        current_user=Depends(get_user_info)
                        ) -> dict[str,Any]:
    result = await publish_produce(
        user_id=current_user["id"],
        produce_name=product_name,
        price=price,
        original_price=original_price,
        description=description,
        category_id=category_id,
        campus=campus,
        images=images,
    )
    return result

"""获取我的商品接口"""
@products.get("/api/my")
async def my_products(current_user = Depends(get_user_info)
                    ,page:int = Query(1,ge=1),
                    page_size:int = Query(20,ge=1,le=100)) -> dict[str,Any]:
    result = await get_my_products(
        user_id=current_user["id"],
        page=page,page_size=page_size)
    return result

"""收藏商品接口"""
@products.post("/api/favorite/{product_id}")
async def favorite_item(product_id:int,current_user = Depends(get_user_info)) -> dict[str, Any]:
    result = await favorite_produce(
        user_id=current_user["id"],
        product_id=product_id
    )
    return {"code":200,
            "message":"收藏成功"}

"""取消收藏商品接口"""
@products.delete("/api/favorite/{product_id}")
async def delete_favorite_product(product_id:int,current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await unfavorite_produce(
        user_id=current_user["id"],
        product_id=product_id
    )
    return {
        "code":200,
        "message":"取消收藏成功"
    }

"""获取收藏列表接口"""
@products.get("/api/favorite")
async def get_favorites_list(current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await get_my_favorite(current_user["id"])
    return {
        "code":200,
        "message":"获取收藏成功",
        "data":result
    }

"""获取他人商品接口"""
@products.get("/api/users/{other_user_id}/products")
async def get_other_user_products(other_user_id:int,page:int = Query(1,ge=1),
                                page_size:int = Query(20,ge=1,le=100)) -> dict[str,Any]:
    result = await get_others_products(
        other_user_id=other_user_id,
        page=page,
        page_size=page_size
    )
    return result

"""删除商品接口"""
@products.delete("/api/products/{product_id}")
async def delete_product_api(product_id: int,current_user=Depends(get_user_info)) -> dict[str,Any]:
    result = await delete_my_product(
        user_id=current_user["id"],
        product_id=product_id)
    return result

"""修改商品接口"""
@products.patch("/api/products/{product_id}")
async def change_product_info(
        product_id: int,
        data:ProductUpdate,
        current_user=Depends(get_user_info)) -> dict[str,Any]:
        result = await change_my_product(
                user_id=current_user["id"],
                product_id=product_id,
                **data.model_dump(exclude_unset=True)
            )
        return result

"""标记商品售出接口"""
@products.patch("/api/products/{product_id}/sold")
async def mark_product_as_sold(product_id:int,current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await mark_as_sold(
        user_id=current_user["id"],
        product_id=product_id
    )
    return result



























