"""公告接口"""
from typing import Any
from fastapi import APIRouter
from crud_1.announcements import get_announcements


announcements = APIRouter()


"""获取公告接口"""
@announcements.get("/api/announcements")
async def get_all_announcements() -> dict[str,Any]:
    result = await get_announcements()
    return result