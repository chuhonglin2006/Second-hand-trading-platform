"""用户接口"""
from typing import Any
from crud_1.users import user_login,get_user_info,send_code,user_register,get_seller_public_info
from fastapi import APIRouter,Depends,Request
from schemas_1.user import Logion,SendCodeRequest,Register


user = APIRouter()


"""用户登录接口"""
@user.post("/api/auth/login")
async def login(data:Logion,request:Request) -> dict[str,Any]:
    login_ip = request.headers.get("X-Forwarded-For")
    if login_ip:
        login_ip = login_ip.split(",")[0].strip()
    else:
        login_ip = request.client.host if request.client else ""
    result = await user_login(data.user_email,data.password,login_ip)
    return result

"""获取当前用户信息接口"""
@user.get("/api/auth/me")
async def get_info(user_info:dict = Depends(get_user_info)) -> dict[str,Any]:
    return user_info

"""发送验证码接口"""
@user.post("/api/auth/send-code")
async def send_register_code(user_email:SendCodeRequest) -> dict[str, int | str]:
    await send_code(user_email.user_email)
    return {
        "code": 200,
        "message": "验证码发送成功"
    }

"""用户注册接口"""
@user.post("/api/auth/register")
async def register(data:Register,request:Request) -> dict[Any, Any]:
    register_ip = request.headers.get("X-Forwarded-For")
    if register_ip:
        register_ip = register_ip.split(",")[0].strip()
    else:
        register_ip = request.client.host if request.client else ""
    result = await user_register(data.username,data.student_id,data.email,data.password,data.code,register_ip)
    return result

"""获取其他卖家公共信息"""
@user.get("/api/users/{user_id}")
async def get_other_seller_info(user_id:int) -> dict[str,Any]:
    result = await get_seller_public_info(user_id)
    return result

