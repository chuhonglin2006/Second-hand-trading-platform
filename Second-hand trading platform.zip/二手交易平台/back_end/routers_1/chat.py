"""用户聊天接口"""
import asyncio
from fastapi import APIRouter,Depends,WebSocket,HTTPException,WebSocketDisconnect
from crud_1.chat import get_or_create_chat, get_message, send_message, get_my_message_list, read_message, \
check_chat_permission
from crud_1.users import get_user_info
from typing import Any
from schemas_1.chat import SendMessageRequest,WSMessage
from tools_1.websocket_manager import manager
from tools_1.create_token import verify_websocket_token
from pydantic import ValidationError
from fastapi.encoders import jsonable_encoder




chat = APIRouter()


"""获取/创建 订单聊天接口"""
@chat.post("/api/chat/conversations")
async def create_or_get_chat(order_id:int,current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await get_or_create_chat(
        user_id=current_user["id"],
        order_id=order_id
    )
    return result

"""获取聊天信息接口"""
@chat.get("/api/chat/conversations/{conversation_id}/messages")
async def get_my_messages(conversation_id:int,current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await get_message(
        user_id=current_user["id"],
        conversation_id=conversation_id
    )
    return result

"""发送消息接口"""
@chat.post("/api/chat/conversations/{conversation_id}/messages")
async def send_msg(conversation_id:int,data:SendMessageRequest,current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await send_message(
        user_id=current_user["id"],
        content=data.content,
        conversation_id=conversation_id
    )
    return result

"""获取所有聊天信息接口"""
@chat.get("/api/chat/conversations")
async def get_all_msg(current_user = Depends(get_user_info)) -> dict[str,Any]:
    result = await get_my_message_list(
        user_id=current_user["id"]
    )
    return result

"""标记消息已读接口"""
@chat.post("/api/chat/messages/{message_id}/read")
async def read_msg(message_id: int,current_user=Depends(get_user_info)) -> dict[str, Any]:
    user_id = current_user["id"]
    result = await read_message(
        user_id=user_id,
        message_id=message_id
    )
    if result["code"] != 200:
        return result
    data = result["data"]
    if data.get("newly_read", False):
        await manager.broadcast(
            data["conversation_id"],
            {
                "type": "read",
                "data": {
                    "message_ids": [message_id],
                    "reader_id": user_id
                }
            }
        )
    return result

"""WebSocket接口"""
@chat.websocket("/api/chat/ws/{conversation_id}")
async def chat_websocket(websocket:WebSocket,conversation_id:int) -> None:
    """
    WebSocket 聊天
    :param websocket:Websocket
    :param conversation_id:会话id
    :return:
    """
    connected = False
    await websocket.accept()
    try:
        try:
            auth_data = await asyncio.wait_for(
                websocket.receive_json(),
                timeout=10
            )
        except ValueError:
            await websocket.close(
                code=1008,reason="认证信息无效"
            )
            return
        if (
            not isinstance(auth_data,dict)
            or auth_data.get("type") != "auth"
            or not isinstance(auth_data.get("token"),str)
        ):
            await websocket.close(
                code=1008,reason="认证信息无效"
            )
            return
        try:
            current_user  = await verify_websocket_token(auth_data["token"])
            user_id = current_user["id"]
            await check_chat_permission(
                user_id=user_id,
                conversation_id=conversation_id
            )
            manager.connect(conversation_id, websocket)
            connected = True
            await websocket.send_json({
                "type": "auth_success",
                "user_id": user_id
            })
        except (HTTPException,ValueError):
            await websocket.close(
                code=1008,reason="认证失败或无权访问"
            )
            return
        while True:
            try:
                raw_data = await websocket.receive_json()
            except ValueError:
                """收到的不是合法JSON,提示后继续等待下一条"""
                await websocket.send_json({
                    "type": "error",
                    "message": "消息格式不正确"
                })
                continue
            try:
                data = WSMessage.model_validate(raw_data)
            except ValidationError:
                await websocket.send_json({
                    "type": "error",
                    "message": "消息格式不正确"
                })
                continue
            if data.type == "ping":
                await websocket.send_json({
                    "type":"pong"
                })
                continue
            if data.type != "message":
                await websocket.send_json({
                    "type": "error",
                    "message": "不支持的消息类型"
                })
                continue
            content = (data.content or "").strip()
            if not content:
                await websocket.send_json({
                    "type": "error",
                    "message": "消息不能为空"
                })
                continue
            try:
                result = await send_message(
                    user_id=user_id,
                    content=content,
                    conversation_id=conversation_id
                )
            except HTTPException as exc:
                await websocket.send_json({
                    "type": "error",
                    "message": str(exc.detail)
                })
                continue
            await manager.broadcast(
                conversation_id,
                {
                    "type": "message",
                    "data": jsonable_encoder(result["data"])
                }
            )
    except WebSocketDisconnect:
        pass
    except asyncio.TimeoutError:
        await websocket.close(
            code=1008,
            reason="认证超时"
        )
    finally:
        if connected:
            manager.disconnect(conversation_id, websocket)











































