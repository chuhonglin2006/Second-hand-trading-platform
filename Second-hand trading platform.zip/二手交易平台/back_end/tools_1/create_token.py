"""生成用户登录token"""
from datetime import datetime,timezone,timedelta
from typing import Any
from jose import jwt
from fastapi import HTTPException,status
import os
from dotenv import load_dotenv
from pathlib import Path
from sqlalchemy import select
from database_1.database_config import async_session_maker
from modles_1.user import User


key_env_path = Path(__file__).resolve().parent.parent / "keys.env"
load_dotenv(key_env_path)
SECRET_KEY = os.getenv('SECRET_KEY')
ALGORITHM = os.getenv('ALGORITHM')
ACCESS_TOKEN_EXPIRE_MINUTES = 60


def create_token(data:dict) -> str:
    """
    生成用户登录时的token
    :param data:登录时的数据
    :return:token
    """
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes = ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, str(SECRET_KEY), algorithm=str(ALGORITHM))

def decode_token(token:str) -> dict[str, Any]:
    """
    解码token
    :param token:token
    :return:解码后的数据
    """
    try:
        payload = jwt.decode(token,str(SECRET_KEY),algorithms = [ALGORITHM])
        return payload
    except Exception:
        raise HTTPException(status_code = status.HTTP_401_UNAUTHORIZED,
                            detail='token无效或已过期')

async def verify_websocket_token(token:str) -> dict[str,Any]:
    """
    解码WebSocket token
    :param token:token
    :return:解码信息
    """
    payload = decode_token(token)
    user_id = payload.get("user_id")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token缺少用户id"
        )
    async with async_session_maker() as session:
        stmt = select(User).where(
            User.id == user_id
        )
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在"
            )
        if user.status == "banned":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="账户已被封禁"
            )
        return {
            "id":user.id,
            "username":user.username
        }
