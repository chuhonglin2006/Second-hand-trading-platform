"""WebSocket管理器"""

from collections import defaultdict
from fastapi import WebSocket


class ConnectionManager:

    def __init__(self):
        self.active_connections: dict[
            int, set[WebSocket]
        ] = defaultdict(set)

    def connect(
        self,
        conversation_id: int,
        websocket: WebSocket
    ) -> None:
        self.active_connections[conversation_id].add(websocket)

    def disconnect(
        self,
        conversation_id: int,
        websocket: WebSocket
    ) -> None:
        connections = self.active_connections.get(conversation_id)

        if connections is None:
            return

        connections.discard(websocket)

        if not connections:
            self.active_connections.pop(conversation_id, None)

    async def broadcast(
        self,
        conversation_id: int,
        data: dict
    ) -> None:
        connections = list(
            self.active_connections.get(conversation_id, set())
        )

        for websocket in connections:
            try:
                await websocket.send_json(data)
            except Exception:
                self.disconnect(conversation_id, websocket)


manager = ConnectionManager()