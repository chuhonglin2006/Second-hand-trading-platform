"""公告接口函数"""
from typing import Any
from modles_1.announcements import Announcements
from database_1.database_config import async_session_maker
from sqlalchemy import select


async def get_announcements() -> dict[str,Any]:
    """
    获取公告函数
    :return:公告信息
    """
    async with async_session_maker() as session:
        stmt = (select(Announcements).order_by(
            Announcements.created_at.desc(),
            Announcements.id.desc()
        ))
        announcements_class = await session.execute(stmt)
        announcements = announcements_class.scalars().all()
        return {
            "code": 200,
            "message": "获取公告成功",
            "data": [
                {
                    "id": announcement.id,
                    "title": announcement.title,
                    "content": announcement.content,
                    "created_at": announcement.created_at.isoformat()
                }
                for announcement in announcements
            ]
        }

