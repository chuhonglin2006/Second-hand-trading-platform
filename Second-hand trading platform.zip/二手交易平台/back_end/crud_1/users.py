"""用户接口函数"""
from typing import Any
from database_1.database_config import async_session_maker
from modles_1.user import User
from sqlalchemy import select,update
from tools_1.password_hash import check_password,password_hash
from tools_1.create_token import create_token,decode_token
from fastapi import HTTPException, status, Header
from modles_1.email_verification_code import EmailVerificationCode
from datetime import datetime, timedelta
from tools_1.email import send_email
import secrets
from tools_1.check_student_id import check_student_id



async def user_register(username:str,student_id:str,user_email:str,password:str,email_code:str,register_ip:str = '') -> \
dict[Any, Any]:
    """
    用户注册接口
    1.验证学号
    2.查询邮箱是否已经注册
    3.查询最新注册验证码
    4.检查验证码是否存在
    5.检查验证码是否过期
    6.检查验证码是否正确
    7.创建用户
    8.将验证码标记为已使用
    :param student_id:学号
    :param username:用户名
    :param register_ip:注册ip地址
    :param email_code:邮箱验证码
    :param user_email:用户邮箱
    :param password:用户密码
    :return:用户信息
    """
    username = (username or "").strip()
    user_email = (user_email or "").strip()
    if not username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用户名不能为空")
    if len(username) > 50:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="用户名不能超过50个字符")
    if not user_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="邮箱不能为空")
    if len(user_email) > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="邮箱长度不能超过100个字符")
    if not password or len(password) < 6:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="密码至少需要6位")
    if len(password) > 64:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="密码不能超过64位")
    async with async_session_maker() as session:
        if not check_student_id(student_id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="学号格式错误或不在有效入学范围内")
        stmt = select(User).where(User.email == user_email)
        result = await session.execute(stmt)
        if result.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="邮箱已注册")
        stmt = select(User).where(User.username == username)
        result = await session.execute(stmt)
        if result.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="用户名已存在")
        stmt = select(User).where(User.student_id == student_id)
        result = await session.execute(stmt)
        if result.scalar_one_or_none() is not None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="学号已注册")
        stmt = (
            select(EmailVerificationCode)
            .where(
                EmailVerificationCode.email == user_email,
                EmailVerificationCode.purpose == "register",
                EmailVerificationCode.is_used.is_(False)
            )
            .order_by(
                EmailVerificationCode.created_at.desc()
            )
            .limit(1))
        email_class = await session.execute(stmt)
        result = email_class.scalar_one_or_none()
        if result is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="验证码不存在或已使用")
        if result.expires_at <= datetime.now():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="验证码已过期")
        if result.code != email_code:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="验证码错误")
        result.is_used = True
        result.used_at = datetime.now()
        hash_password = password_hash(password)
        user = User(
            username=username,
            email=user_email,
            password_hash=hash_password,
            student_id=student_id,
            register_ip=register_ip,)
        session.add(user)
        await session.commit()
        await session.refresh(user)
        token = create_token({
            "user_id": user.id})
        return {
            "access_token": token,
            "user": {
                "id": user.id,
                "username": user.username,
                "studentId": user.student_id,
                "campus": user.campus,
                "score": user.credit_score
            }
        }

async def user_login(user_email:str,password:str,login_ip:str) -> dict[str, str | dict[str, Any]]:
    """
    用户登录接口
    1.先查询用户是否存在
    2.若存在判断用户是否封禁
    3.若不存在则返回用户不存在
    4.若用户未封禁则检查用户密码,否则禁止登录
    5.密码对比错误则返回密码错误
    :param login_ip:登录ip
    :param user_email:用户邮箱
    :param password:密码
    :return:用户token,id,邮箱
    """
    async with async_session_maker() as session:
        stmt = select(User).where(User.email == user_email)
        user_class = await session.execute(stmt)
        user = user_class.scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail='用户不存在'
            )
        if user.status == "banned":
            if user.banned_until is None:
                raise HTTPException(
                    status_code=400,
                    detail="账号已被永久封禁"
                )
            if datetime.now() < user.banned_until:
                raise HTTPException(
                    status_code=400,
                    detail=f"账号已被封禁至 {user.banned_until}"
                )
            user.status = "normal"
            user.banned_until = None
        if not check_password(password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail='用户名或密码错误'
            )
        user.last_login_at = datetime.now()
        user.last_login_ip = login_ip
        await session.commit()
        token = create_token({
            "user_id": user.id
        })
        return {
            "access_token": token,
            "user": {
                "id": user.id,
                "username": user.username,
                "studentId": user.student_id,
                "campus": user.campus,
                "score": user.credit_score
            }
        }

async def get_user_info(authorization:str = Header(...)) -> dict[str, Any | None]:
    """
    获取当前用户信息
    1.获取Authorization 请求头
    2.检查Bearer 格式
    3.解码JWT
    4.获取user_id
    5.根据user_id查询数据库
    6.返回最新用户信息
    :param authorization:授权码
    :return:用户信息
    """
    if not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="认证头格式错误，应为: Bearer <token>"
        )
    token = authorization.split(" ", 1)[1]
    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="token不能为空"
        )
    payload  = decode_token(token)
    user_id = payload.get("user_id")
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="缺少必要信息"
        )
    async with async_session_maker() as session:
        stmt = select(User).where(User.id == user_id)
        user_class = await session.execute(stmt)
        user = user_class.scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="用户不存在"
            )
        if user.status == "banned":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="账户已被封禁"
            )
        return {
            'id':user.id,
            "username":user.username,
            "studentId":user.student_id,
            "campus":user.campus,
            "score":user.credit_score
        }

async def get_optional_user_info(authorization:str | None = Header(default=None)) -> dict[str, Any] | None:
    """
    可选登录信息

    用于既允许游客访问、又需要识别登录用户的接口。
    未携带 token、token 无效或账户不可用时返回 None,
    由调用方按游客身份处理,不抛出异常。
    :param authorization:授权码
    :return:用户信息或None
    """
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.split(" ", 1)[1].strip()
    if not token:
        return None
    try:
        payload = decode_token(token)
    except HTTPException:
        return None
    user_id = payload.get("user_id")
    if user_id is None:
        return None
    async with async_session_maker() as session:
        user = await session.scalar(
            select(User).where(User.id == user_id)
        )
        if user is None or user.status == "banned":
            return None
        return {
            "id": user.id,
            "username": user.username,
            "studentId": user.student_id,
            "campus": user.campus,
            "score": user.credit_score
        }

async def send_code(user_email:str) -> None:
    """
    发送邮箱验证码,并将验证码存入数据库
    1.确认60秒的限制时间
    2.60秒未过则抛出异常,过了就查找以前已经发送的验证码
    3.将以前已经发送但是未过期的验证码全部作废
    4.生成验证码和邮件内容
    5.将验证码信息存入数据库
    6.发送验证码
    :param user_email:用户邮箱
    :return:
    """
    async with async_session_maker() as session:
        stmt = (select(EmailVerificationCode).where(
                EmailVerificationCode.email == user_email,
                EmailVerificationCode.purpose == "register"
            ).order_by(EmailVerificationCode.created_at.desc()).limit(1))
        result = await session.execute(stmt)
        last_code = result.scalar_one_or_none()
        if last_code is not None:
            elapsed = (datetime.now() - last_code.created_at).total_seconds()
            if elapsed < 60:
                remaining = int(60 - elapsed)
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"请{remaining}秒后重试"
                )
        stmt = (update(EmailVerificationCode).where(
            EmailVerificationCode.email == user_email,
            EmailVerificationCode.purpose == "register",
            EmailVerificationCode.is_used.is_(False)
        ).values(is_used = True))
        await session.execute(stmt)
        email_code = secrets.randbelow(900000) + 100000
        mail_content = f"你的验证码为:{email_code},5分钟内有效,请不要将验证码告诉他人!"
        code_info = EmailVerificationCode(
            email=user_email,
            code=str(email_code),
            purpose="register",
            is_used=False,
            created_at=datetime.now(),
            expires_at=datetime.now() + timedelta(minutes=5)
        )
        session.add(code_info)
        await session.commit()
        send_email(user_email, mail_content)

async def get_seller_public_info(seller_id:int) -> dict[str,Any]:
    """
    获取其他卖家公共信息
    :param seller_id:用户id
    :return:其他用户公共信息
    """
    async with async_session_maker() as session:
        stmt = select(User).where(
            User.id == seller_id,
            User.status == "normal"
        )
        user_class = await session.execute(stmt)
        user = user_class.scalar_one_or_none()
        if user is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="用户不存在或已被封禁"
            )
        return {
            "code":200,
            "message":"获取成功",
            "data":{
                "id":user.id,
                "username":user.username,
                "campus":user.campus,
                "score":user.credit_score
            }
        }































