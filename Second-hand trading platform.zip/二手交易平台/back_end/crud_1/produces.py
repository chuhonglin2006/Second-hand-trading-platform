"""商品接口函数"""
import datetime
from typing import Any

from sqlalchemy import select, func, update, delete, or_
from sqlalchemy.orm import selectinload
from modles_1.products import Product
from database_1.database_config import async_session_maker
from fastapi import HTTPException, status, UploadFile
from decimal import Decimal
from tools_1.review_product import validate_product
from tools_1.uload_image_to_server import (
    upload_image,
    get_image_filename,
    delete_image,
    normalize_image_url)
from modles_1.product_image import ProductImage
from modles_1.favorite import Favorite
from modles_1.category import Category
from modles_1.chat import ChatConversation, ChatMessage
from tools_1.get_six_mouth import get_six_months_ago
from modles_1.order import Order


async def get_products_list(page: int, page_size: int) -> dict[str, Any]:
    """
    获取商品列表
    1.获取所有商品并返回
    :return: 商品列表
    """
    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .where(
                Product.status == "on_sale",
                Product.review_status == "approved"
            )
            .options(
                selectinload(Product.category),
                selectinload(Product.seller),
                selectinload(Product.images)
            )
            .order_by(Product.created_at.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )

        products_class = await session.execute(stmt)
        products = products_class.scalars().all()

        count_stmt = (
            select(func.count(Product.id))
            .where(
                Product.status == "on_sale",
                Product.review_status == "approved"
            )
        )

        total_result = await session.execute(count_stmt)
        total = total_result.scalar_one()

        products_list = []

        for product in products:
            products_list.append({
                "id": product.id,
                "name": product.name,
                "price": product.price,
                "original_price": product.original_price,
                "description": product.description,
                "status": product.status,
                "view_count": product.view_count,
                "campus": product.campus,
                "created_at": product.created_at,

                # 统一转换图片地址
                "images": [
                    normalize_image_url(image.image_url)
                    for image in product.images
                ],

                "category": {
                    "id": product.category.id,
                    "key": product.category.key,
                    "name": product.category.name,
                },

                "seller": {
                    "id": product.seller.id,
                    "username": product.seller.username,
                }
            })

        return {
            "code": 200,
            "message": "获取成功",
            "data": products_list,
            "total": total,
            "page": page,
            "page_size": page_size
        }


async def get_produce_info(
    product_id: int,
    viewer_id: int | None = None
) -> dict[str, Any]:
    """
    获取商品详细信息

    1.根据商品id查询商品详细信息并返回
    2.在售且已过审的商品所有人可见
    3.卖家本人、以及该商品订单的买卖双方可以查看非在售商品

    :param product_id: 商品id
    :param viewer_id: 当前访问者id(可为None,表示游客)
    :return:
    """
    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .options(
                selectinload(Product.category),
                selectinload(Product.seller),
                selectinload(Product.images)
            )
            .where(Product.id == product_id)
        )

        produce_class = await session.execute(stmt)
        produce_info = produce_class.scalar_one_or_none()

        if produce_info is not None:
            visible = (
                produce_info.status == "on_sale"
                and produce_info.review_status == "approved"
            )

            if not visible and viewer_id is not None:
                if produce_info.seller_id == viewer_id:
                    visible = True
                else:
                    related_order = await session.scalar(
                        select(Order.id)
                        .where(
                            Order.product_id == product_id,
                            or_(
                                Order.buyer_id == viewer_id,
                                Order.seller_id == viewer_id
                            )
                        )
                        .limit(1)
                    )

                    visible = related_order is not None

            if not visible:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="商品不存在"
                )

        if produce_info:
            await session.execute(
                update(Product)
                .where(Product.id == product_id)
                .values(
                    view_count=Product.view_count + 1
                )
            )

            await session.commit()
            await session.refresh(produce_info)

            return {
                "code": 200,
                "message": "获取成功",
                "data": {
                    "id": produce_info.id,
                    "name": produce_info.name,
                    "price": produce_info.price,
                    "original_price": produce_info.original_price,
                    "description": produce_info.description,
                    "status": produce_info.status,
                    "view_count": produce_info.view_count,
                    "campus": produce_info.campus,
                    "created_at": produce_info.created_at,

                    # 统一转换图片地址
                    "images": [
                        normalize_image_url(image.image_url)
                        for image in produce_info.images
                    ],

                    "category": {
                        "id": produce_info.category.id,
                        "key": produce_info.category.key,
                        "name": produce_info.category.name,
                    },

                    "seller": {
                        "id": produce_info.seller.id,
                        "username": produce_info.seller.username
                    }
                }
            }

        else:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="商品不存在"
            )


async def publish_produce(
    user_id: int,
    produce_name: str,
    price: Decimal,
    original_price: Decimal | None,
    description: str,
    category_id: int,
    campus: str,
    images: list[UploadFile]
) -> dict[str, Any]:
    """
    发布商品

    :param images: 图片列表
    :param user_id: 用户id
    :param produce_name: 商品名称
    :param price: 商品价格
    :param original_price: 商品原价
    :param description: 商品描述
    :param category_id: 分类id
    :param campus: 校区
    :return: 商品信息
    """
    async with async_session_maker() as session:
        try:
            review_passed, review_reason = await validate_product(
                produce_name=produce_name,
                price=price,
                original_price=original_price,
                description=description,
                category_id=category_id,
                campus=campus,
            )

            if not review_passed:
                return {
                    "code": 400,
                    "message": "商品信息审核未通过",
                    "data": {
                        "reason": review_reason
                    }
                }

            product = Product(
                seller_id=user_id,
                name=produce_name,
                price=price,
                original_price=original_price,
                description=description,
                category_id=category_id,
                campus=campus,
                review_status="pending",
                review_reason=None,
                reviewed_at=None,
                status="on_sale",
                view_count=0
            )

            session.add(product)
            await session.flush()

            product_id = product.id
            image_urls = []

            for image in images:
                result = await upload_image(
                    product_id=product_id,
                    file=image
                )

                image_url = result["data"]["image_url"]

                # 防止图片服务器返回完整URL
                # 确保数据库保存 /images/... 格式
                image_url = normalize_image_url(image_url)

                image_urls.append(image_url)

                product_image = ProductImage(
                    product_id=product_id,
                    image_url=image_url
                )

                session.add(product_image)

            await session.commit()

            return {
                "code": 200,
                "message": "商品发布成功，等待后台审核",
                "data": {
                    "id": product.id,
                    "name": product.name,
                    "price": str(product.price),
                    "original_price": (
                        str(product.original_price)
                        if product.original_price is not None
                        else None
                    ),
                    "description": product.description,
                    "category_id": product.category_id,
                    "campus": product.campus,
                    "review_status": product.review_status,
                    "status": product.status,
                    "images": image_urls
                }
            }

        except Exception:
            await session.rollback()
            raise


async def search_product(product_name: str) -> dict[str, Any]:
    """
    搜索商品

    :param product_name: 商品名称
    :return: 搜索结果
    """
    products_name = product_name.strip()

    if not products_name:
        return {
            "code": 400,
            "message": "搜索关键词不能为空",
            "data": []
        }

    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .options(
                selectinload(Product.category),
                selectinload(Product.seller),
                selectinload(Product.images)
            )
            .where(
                Product.name.contains(products_name),
                Product.status == "on_sale",
                Product.review_status == "approved"
            )
            .order_by(Product.created_at.desc())
        )

        products_class = await session.execute(stmt)
        products = products_class.scalars().all()

        products_list = []

        for product in products:
            products_list.append({
                "id": product.id,
                "name": product.name,
                "price": product.price,
                "original_price": product.original_price,
                "description": product.description,
                "status": product.status,
                "view_count": product.view_count,
                "campus": product.campus,
                "created_at": product.created_at,

                # 统一转换图片地址
                "images": [
                    normalize_image_url(image.image_url)
                    for image in product.images
                ],

                "category": {
                    "id": product.category.id,
                    "key": product.category.key,
                    "name": product.category.name
                } if product.category else None,

                "seller": {
                    "id": product.seller.id,
                    "username": product.seller.username
                } if product.seller else None
            })

        return {
            "code": 200,
            "message": "搜索成功",
            "data": products_list
        }


async def get_my_products(
    user_id: int,
    page: int,
    page_size: int
) -> dict[str, Any]:
    """
    获取我的商品

    :param page_size: 页数大小
    :param page: 页数
    :param user_id: 用户id
    :return: 所有商品信息
    """
    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .where(Product.seller_id == user_id)
            .options(
                selectinload(Product.category),
                selectinload(Product.seller),
                selectinload(Product.images)
            )
            .order_by(Product.created_at.desc())
            .offset((page - 1) * page_size)
            .limit(page_size)
        )

        products_class = await session.execute(stmt)
        products = products_class.scalars().all()

        count_stmt = select(func.count(Product.id)).where(
            Product.seller_id == user_id
        )

        total_result = await session.execute(count_stmt)
        total = total_result.scalar_one()

        products_list = []

        for product in products:
            products_list.append({
                "id": product.id,
                "name": product.name,
                "price": product.price,
                "original_price": product.original_price,
                "description": product.description,
                "status": product.status,
                "review_status": product.review_status,
                "view_count": product.view_count,
                "campus": product.campus,
                "created_at": product.created_at,
                "seller_id": product.seller_id,

                # 统一转换图片地址
                "images": [
                    normalize_image_url(image.image_url)
                    for image in product.images
                ],

                "category": {
                    "id": product.category.id,
                    "key": product.category.key,
                    "name": product.category.name
                },

                "seller": {
                    "id": product.seller.id,
                    "username": product.seller.username
                }
            })

        return {
            "code": 200,
            "message": "搜索成功",
            "data": products_list,
            "total": total,
            "page": page,
            "page_size": page_size
        }


async def get_my_product_info(
    user_id: int,
    product_id: int
) -> dict[str, Any]:
    """
    获取本人商品详细信息

    与商品列表接口不同，这里不限制商品状态，
    审核中/已下架/已售出的商品卖家本人都能查看和编辑。

    :param user_id: 用户id
    :param product_id: 商品id
    :return: 商品详细信息
    """
    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .where(
                Product.id == product_id,
                Product.seller_id == user_id
            )
            .options(
                selectinload(Product.category),
                selectinload(Product.seller),
                selectinload(Product.images)
            )
        )

        product_class = await session.execute(stmt)
        product = product_class.scalar_one_or_none()

        if product is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="商品不存在或无权查看"
            )

        return {
            "code": 200,
            "message": "获取成功",
            "data": {
                "id": product.id,
                "name": product.name,
                "price": product.price,
                "original_price": product.original_price,
                "description": product.description,
                "status": product.status,
                "review_status": product.review_status,
                "review_reason": product.review_reason,
                "view_count": product.view_count,
                "campus": product.campus,
                "created_at": product.created_at,
                "seller_id": product.seller_id,

                # 统一转换图片地址
                "images": [
                    normalize_image_url(image.image_url)
                    for image in product.images
                ],

                "category": {
                    "id": product.category.id,
                    "key": product.category.key,
                    "name": product.category.name
                } if product.category else None,

                "seller": {
                    "id": product.seller.id,
                    "username": product.seller.username
                } if product.seller else None
            }
        }


async def favorite_produce(
    user_id: int,
    product_id: int
) -> None:
    """
    收藏商品

    :param user_id: 用户id
    :param product_id: 商品id
    :return: None
    """
    async with async_session_maker() as session:
        product_exists = await session.scalar(
            select(Product.id).where(
                Product.id == product_id
            )
        )

        if product_exists is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="商品不存在"
            )

        stmt = select(Favorite.id).where(
            Favorite.user_id == user_id,
            Favorite.product_id == product_id
        )

        user_favorite_products_class = await session.execute(stmt)
        favorite_id = user_favorite_products_class.scalar_one_or_none()

        if favorite_id is not None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="该商品已收藏"
            )

        favorite = Favorite(
            user_id=user_id,
            product_id=product_id
        )

        session.add(favorite)
        await session.commit()


async def unfavorite_produce(
    user_id: int,
    product_id: int
) -> None:
    """
    取消收藏商品

    :param user_id: 用户id
    :param product_id: 商品id
    :return: None
    """
    async with async_session_maker() as session:
        stmt = select(Favorite).where(
            Favorite.user_id == user_id,
            Favorite.product_id == product_id
        )

        favorite_class = await session.execute(stmt)
        favorite = favorite_class.scalar_one_or_none()

        if favorite is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="商品尚未收藏"
            )

        await session.delete(favorite)
        await session.commit()


async def get_my_favorite(user_id: int) -> list[Any]:
    """
    获取我的收藏

    :param user_id: 用户id
    :return: 用户收藏
    """
    async with async_session_maker() as session:
        stmt = (
            select(Favorite.product_id)
            .where(Favorite.user_id == user_id)
            .order_by(Favorite.created_at.desc())
        )

        my_favorite_class = await session.execute(stmt)
        my_favorites = my_favorite_class.scalars().all()

        return list(my_favorites)


async def get_products_category() -> dict[str, Any]:
    """
    获取商品分类列表

    :return: 商品分类列表
    """
    async with async_session_maker() as session:
        stmt = (
            select(Category)
            .order_by(
                Category.sort_order.asc(),
                Category.id.asc()
            )
        )

        categories_class = await session.execute(stmt)
        categories = categories_class.scalars().all()

        return {
            "code": 200,
            "message": "获取分类成功",
            "data": [
                {
                    "id": category.id,
                    "key": category.key,
                    "name": category.name,
                    "sort_order": category.sort_order
                }
                for category in categories
            ]
        }


async def get_others_products(
    other_user_id: int,
    page: int,
    page_size: int
) -> dict[str, Any]:
    """
    获取他人商品

    :param other_user_id: 用户id
    :param page: 页数
    :param page_size: 页数大小
    :return: 其他用户商品
    """
    async with async_session_maker() as session:
        stmt = (
            select(Product)
            .where(
                Product.seller_id == other_user_id,
                Product.status == "on_sale",
                Product.review_status == "approved"
            )
            .options(
                selectinload(Product.images)
            )
            .order_by(
                Product.created_at.desc(),
                Product.id.desc()
            )
            .offset((page - 1) * page_size)
            .limit(page_size)
        )

        count_stmt = select(func.count(Product.id)).where(
            Product.seller_id == other_user_id,
            Product.status == "on_sale",
            Product.review_status == "approved"
        )

        total = (
            await session.execute(count_stmt)
        ).scalar_one()

        other_user_products_class = await session.execute(stmt)
        other_user_products = other_user_products_class.scalars().all()

        return {
            "code": 200,
            "message": "获取用户商品成功",
            "data": [
                {
                    "id": product.id,
                    "name": product.name,
                    "price": float(product.price),
                    "created_at": product.created_at.isoformat(),

                    # 返回商品图片
                    "images": [
                        normalize_image_url(image.image_url)
                        for image in product.images
                    ]
                }
                for product in other_user_products
            ],
            "total": total,
            "page": page,
            "page_size": page_size
        }












async def delete_my_product(
    user_id: int,
    product_id: int
) -> dict[str, Any]:
    """
    删除商品

    :param user_id: 用户id
    :param product_id: 商品id
    :return: 商品信息
    """
    async with async_session_maker() as session:
        stmt = select(Product).where(
            Product.id == product_id,
            Product.seller_id == user_id
        )

        product_class = await session.execute(stmt)
        product = product_class.scalar_one_or_none()

        if product is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="商品不存在或无权删除"
            )

        order_stmt = select(Order).where(
            Order.product_id == product_id
        )

        order_class = await session.execute(order_stmt)
        orders = order_class.scalars().all()

        now = datetime.datetime.now()
        six_months_ago = get_six_months_ago(now)

        for order in orders:
            if order.status == "pending":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="该商品存在待完成订单，暂时不能删除"
                )

            if order.status == "completed":
                if order.completed_at is None:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="该商品存在已完成但缺少完成时间的订单，暂时不能删除"
                    )

                if order.completed_at > six_months_ago:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="该商品存在未满6个月的已完成订单，暂时不能删除"
                    )

        # 先删除图片服务器上的实际文件
        image_stmt = select(ProductImage).where(
            ProductImage.product_id == product_id
        )

        images_class = await session.execute(image_stmt)
        images = images_class.scalars().all()

        for image in images:
            file_name = get_image_filename(
                image.image_url
            )

            try:
                await delete_image(
                    product_id=product_id,
                    file_name=file_name
                )
            except Exception as e:
                await session.rollback()

                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"删除商品图片失败: {e}"
                )

        # 先删除聊天消息和会话
        # chat_conversations 通过 order_id 关联订单
        order_ids = (
            await session.execute(
                select(Order.id).where(
                    Order.product_id == product_id
                )
            )
        ).scalars().all()

        if order_ids:
            conversation_ids = (
                await session.execute(
                    select(ChatConversation.id).where(
                        ChatConversation.order_id.in_(order_ids)
                    )
                )
            ).scalars().all()

            if conversation_ids:
                await session.execute(
                    delete(ChatMessage).where(
                        ChatMessage.conversation_id.in_(
                            conversation_ids
                        )
                    )
                )

                await session.execute(
                    delete(ChatConversation).where(
                        ChatConversation.id.in_(conversation_ids)
                    )
                )

        # 删除收藏记录
        await session.execute(
            delete(Favorite).where(
                Favorite.product_id == product_id
            )
        )

        # 删除订单
        await session.execute(
            delete(Order).where(
                Order.product_id == product_id
            )
        )

        # 删除商品图片记录
        await session.execute(
            delete(ProductImage).where(
                ProductImage.product_id == product_id
            )
        )

        # 删除商品
        await session.delete(product)

        await session.commit()

        return {
            "code": 200,
            "message": "删除成功"
        }


async def change_my_product(
    user_id: int,
    product_id: int,
    product_name: str | None = None,
    price: Decimal | None = None,
    original_price: Decimal | None = None,
    description: str | None = None,
    category_id: int | None = None,
    campus: str | None = None,
) -> dict[str, Any]:
    """
    修改商品信息，修改后重新进入待审核状态
    """
    async with async_session_maker() as session:
        stmt = select(Product).where(
            Product.id == product_id,
            Product.seller_id == user_id
        )

        result = await session.execute(stmt)
        product = result.scalar_one_or_none()

        if product is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="商品不存在"
            )

        if product.status == "sold":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="已售出的商品不能修改"
            )

        # 先合并出修改后的最终值，再统一校验
        new_name = (
            product.name
            if product_name is None
            else product_name.strip()
        )

        new_price = (
            product.price
            if price is None
            else price
        )

        new_original_price = (
            product.original_price
            if original_price is None
            else original_price
        )

        new_description = (
            product.description
            if description is None
            else description.strip()
        ) or ""

        new_category_id = (
            product.category_id
            if category_id is None
            else category_id
        )

        new_campus = (
            product.campus
            if campus is None
            else campus.strip()
        ) or ""

        review_passed, review_reason = await validate_product(
            produce_name=new_name,
            price=new_price,
            original_price=new_original_price,
            description=new_description,
            category_id=new_category_id,
            campus=new_campus
        )

        if not review_passed:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=review_reason
            )

        if new_category_id != product.category_id:
            category_exists = await session.scalar(
                select(Category.id).where(
                    Category.id == new_category_id
                )
            )

            if category_exists is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="商品分类不存在"
                )

        changed = False

        if product.name != new_name:
            product.name = new_name
            changed = True

        if product.price != new_price:
            product.price = new_price
            changed = True

        if product.original_price != new_original_price:
            product.original_price = new_original_price
            changed = True

        if (product.description or "") != new_description:
            product.description = new_description
            changed = True

        if product.category_id != new_category_id:
            product.category_id = new_category_id
            changed = True

        if (product.campus or "") != new_campus:
            product.campus = new_campus
            changed = True

        if changed:
            product.review_status = "pending"
            product.review_reason = None
            product.reviewed_at = None
            product.reviewed_by = None

        await session.commit()
        await session.refresh(product)

        return {
            "code": 200,
            "message": (
                "商品修改成功，等待重新审核"
                if changed
                else "商品信息未发生变化"
            ),
            "data": {
                "id": product.id,
                "name": product.name,
                "price": product.price,
                "original_price": product.original_price,
                "description": product.description,
                "category_id": product.category_id,
                "campus": product.campus,
                "status": product.status,
                "review_status": product.review_status
            }
        }


async def mark_as_sold(
    user_id: int,
    product_id: int
) -> dict[str, Any]:
    """
    商品标记售出

    :param user_id: 用户id
    :param product_id: 商品id
    :return: 商品信息
    """
    async with async_session_maker() as session:
        stmt = select(Product).where(
            Product.id == product_id,
            Product.seller_id == user_id,
            Product.status == "on_sale",
            Product.review_status == "approved"
        )

        result = await session.execute(stmt)
        product = result.scalar_one_or_none()

        if product is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="商品不存在或当前状态不允许标记售出"
            )

        product.status = "sold"
        product.sold_at = datetime.datetime.now()

        await session.commit()
        await session.refresh(product)

        return {
            "code": 200,
            "message": "商品已标记为售出",
            "data": {
                "id": product.id,
                "status": product.status,
                "review_status": product.review_status,
                "sold_at": product.sold_at
            }
        }