"""邮箱验证码模型类"""
from sqlalchemy.orm import Mapped,mapped_column
from sqlalchemy import BigInteger, String, DateTime, func, Boolean
from datetime import datetime
from typing import Optional
from modles_1.base import Base


class EmailVerificationCode(Base):
    __tablename__ = 'email_verification_codes'
    id:Mapped[int] = mapped_column(BigInteger,primary_key=True,autoincrement=True)
    email:Mapped[str] = mapped_column(String(128),nullable=False)
    code:Mapped[str] = mapped_column(String(6),nullable=False)
    purpose:Mapped[str] = mapped_column(String(20),nullable=False,default='register')
    ip_address:Mapped[str] = mapped_column(String(45),nullable=True)
    is_used:Mapped[bool] = mapped_column(Boolean,nullable=False,default=False)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    expires_at:Mapped[datetime] = mapped_column(DateTime,nullable=False)
    created_at:Mapped[datetime] = mapped_column(DateTime,server_default=func.now())
