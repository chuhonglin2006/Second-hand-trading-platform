"""校园二手交易平台主文件"""
from fastapi import FastAPI
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from routers_1.user import user
from routers_1.products import products
from routers_1.announcements import announcements
from routers_1.orders import order
import asyncio
from contextlib import asynccontextmanager
from crud_1.orders import auto_receive_orders
from routers_1.reports import report
from routers_1.chat import chat
from admin.routerd_a.admins import admin
from pathlib import Path
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse
from admin.routerd_a.users import admin_user
from admin.routerd_a.products import admin_product
from admin.routerd_a.orders import admin_order
from admin.routerd_a.overview import admin_overview
from admin.routerd_a.reports import admin_reports
from admin.routerd_a.announcements import admin_announcement




async def order_auto_receive_loop() -> None:
    """
    订单自动收货
    :return:None
    """
    while True:
        try:
            await auto_receive_orders()
        except Exception as e:
            print(f"[订单自动收货] 执行失败: {e}")
        await asyncio.sleep(5 * 1)



@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(
        order_auto_receive_loop())
    print("[订单自动处理] 后台任务已启动")
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass
        print("[订单自动处理] 后台任务已停止")



app = FastAPI(lifespan=lifespan)



"""添加中间件"""
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    # 本项目使用 Authorization 头携带 token 而不是 Cookie,
    # 因此不能与 allow_origins=["*"] 组合开启 allow_credentials,
    # 否则浏览器会直接拒绝该跨域响应
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

"""挂载管理员后台界面"""
ADMIN_STATIC = (
    Path(__file__).resolve().parent
    / "admin"
    / "static"
)
@app.get("admin", include_in_schema=False)
async def admin_redirect():
    return RedirectResponse("/admin/login.html")
app.mount(
    "/admin",
    StaticFiles(
        directory=str(ADMIN_STATIC),
        html=True
    ),
    name="admin_static"
)





"""添加路由"""
app.include_router(user)
app.include_router(products)
app.include_router(announcements)
app.include_router(order)
app.include_router(report)
app.include_router(chat)
app.include_router(admin)
app.include_router(admin_user)
app.include_router(admin_product)
app.include_router(admin_order)
app.include_router(admin_overview)
app.include_router(admin_reports)
app.include_router(admin_announcement)








if __name__ == '__main__':
    uvicorn.run(app,host='0.0.0.0',port=8000)
