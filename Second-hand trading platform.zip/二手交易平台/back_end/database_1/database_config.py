"""数据库配置"""
import os
from typing import AsyncGenerator, Any
from dotenv import load_dotenv
from sqlalchemy.ext.asyncio import create_async_engine,async_sessionmaker,AsyncSession
from pathlib import Path
from sqlalchemy import URL


def get_database_url() -> URL:
    """
    获取数据库连接URL
    :return:数据库连接URL
    """
    key_env_path = Path(__file__).resolve().parent.parent / "keys.env"
    load_dotenv(key_env_path)
    DATABASE_NAME = os.getenv('DATABASE_NAME')
    DATABASE_PORT = os.getenv('DATABASE_PORT')
    DATABASE_HOST = os.getenv('DATABASE_HOST')
    DATABASE_USER = os.getenv('DATABASE_USER')
    DATABASE_PASSWORD = os.getenv('DATABASE_PASSWORD')
    DB_URL = URL.create(
            drivername="mysql+aiomysql",
            username=DATABASE_USER,
            password=DATABASE_PASSWORD,
            host=DATABASE_HOST,
            port=int(DATABASE_PORT or 3306),
            database=DATABASE_NAME,
            query={"charset": "utf8mb4"}
            )
    return DB_URL

"""创建异步引擎"""
async_engine = create_async_engine(
    url = get_database_url(),
    echo = False
)
"""创建异步会话工厂"""
async_session_maker  = async_sessionmaker(
    bind = async_engine,
    class_ = AsyncSession,
    autoflush = False,
    expire_on_commit = False
)

