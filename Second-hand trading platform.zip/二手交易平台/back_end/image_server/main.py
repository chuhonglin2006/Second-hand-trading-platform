from pathlib import Path
import os
import uuid

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles


# ============================================================
# 基础配置
# ============================================================

BASE_DIR = Path(__file__).resolve().parent

# 图片保存目录
IMAGE_DIR = BASE_DIR / "images"
IMAGE_DIR.mkdir(parents=True, exist_ok=True)

# 最大图片大小：10MB
MAX_FILE_SIZE = 10 * 1024 * 1024

# 允许的图片格式
ALLOWED_EXTENSIONS = {
    ".jpg",
    ".jpeg",
    ".png",
    ".webp",
}

# 服务器监听地址
HOST = os.getenv(
    "IMAGE_SERVER_HOST",
    "0.0.0.0"
)

# 图片服务器端口
PORT = int(
    os.getenv(
        "IMAGE_SERVER_PORT",
        "8001"
    )
)

# ============================================================
# 非常重要
#
# 这里不能使用 127.0.0.1
#
# 因为这个 URL 最终会保存到数据库，然后由浏览器访问。
#
# 127.0.0.1 对浏览器来说是“用户自己的电脑”，
# 而不是你的服务器。
# ============================================================

PUBLIC_BASE_URL = os.getenv(
    "IMAGE_SERVER_PUBLIC_URL",
    "http://120.26.37.94:8001"
).rstrip("/")


# ============================================================
# 创建 FastAPI
# ============================================================

app = FastAPI(
    title="校园二手交易平台图片服务器",
    description="校园二手交易平台商品图片上传与管理服务",
    version="1.0.0",
)


# ============================================================
# CORS
# ============================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============================================================
# 静态图片目录
#
# 浏览器访问：
#
# http://120.26.37.94:8001/images/8/xxxxx.png
#
# 实际文件：
#
# IMAGE_DIR/
# └── 8/
#     └── xxxxx.png
# ============================================================

app.mount(
    "/images",
    StaticFiles(directory=str(IMAGE_DIR)),
    name="images",
)


# ============================================================
# 工具函数
# ============================================================

def get_product_dir(product_id: int) -> Path:
    """
    获取商品对应的图片目录。

    例如：

    product_id = 8

    返回：

    images/8/
    """

    product_dir = IMAGE_DIR / str(product_id)

    product_dir.mkdir(
        parents=True,
        exist_ok=True
    )

    return product_dir


def build_image_url(
    product_id: int,
    filename: str
) -> str:
    """
    生成图片公网访问地址。
    """

    return (
        f"{PUBLIC_BASE_URL}"
        f"/images/{product_id}/{filename}"
    )


# ============================================================
# 健康检查
# ============================================================

@app.get("/health")
async def health():
    """
    图片服务器健康检查。
    """

    return {
        "code": 200,
        "message": "图片服务器运行正常",
        "data": {
            "host": HOST,
            "port": PORT,
            "image_dir": str(IMAGE_DIR),
            "public_base_url": PUBLIC_BASE_URL,
        }
    }


# ============================================================
# 上传图片
# ============================================================

@app.post("/api/images/upload")
async def upload_image(
    product_id: int,
    file: UploadFile = File(...)
):
    """
    上传商品图片。

    注意：

    product_id 是 Query 参数。

    正确请求：

    POST
    /api/images/upload?product_id=8

    multipart/form-data:
        file = 图片文件
    """

    # --------------------------------------------------------
    # 检查商品 ID
    # --------------------------------------------------------

    if product_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="商品ID无效"
        )

    # --------------------------------------------------------
    # 检查文件名
    # --------------------------------------------------------

    if not file.filename:
        raise HTTPException(
            status_code=400,
            detail="文件名不能为空"
        )

    # --------------------------------------------------------
    # 获取扩展名
    # --------------------------------------------------------

    suffix = Path(
        file.filename
    ).suffix.lower()

    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="只允许上传 JPG、JPEG、PNG、WEBP 图片"
        )

    # --------------------------------------------------------
    # 读取文件
    # --------------------------------------------------------

    data = await file.read()

    if not data:
        raise HTTPException(
            status_code=400,
            detail="图片文件为空"
        )

    # --------------------------------------------------------
    # 检查文件大小
    # --------------------------------------------------------

    if len(data) > MAX_FILE_SIZE:
        raise HTTPException(
            status_code=400,
            detail="图片大小不能超过10MB"
        )

    # --------------------------------------------------------
    # 获取商品图片目录
    # --------------------------------------------------------

    product_dir = get_product_dir(product_id)

    # --------------------------------------------------------
    # 生成随机文件名
    #
    # 不直接使用用户上传的文件名，
    # 防止特殊字符、中文文件名、文件覆盖等问题。
    # --------------------------------------------------------

    filename = (
        f"{uuid.uuid4().hex}"
        f"{suffix}"
    )

    save_path = product_dir / filename

    # --------------------------------------------------------
    # 保存图片
    # --------------------------------------------------------

    try:
        save_path.write_bytes(data)

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"图片保存失败: {str(e)}"
        )

    # --------------------------------------------------------
    # 生成公网图片 URL
    # --------------------------------------------------------

    image_url = build_image_url(
        product_id,
        filename
    )

    # --------------------------------------------------------
    # 返回
    # --------------------------------------------------------

    return {
        "code": 200,
        "message": "图片上传成功",
        "data": {
            "filename": filename,
            "image_url": image_url,
            "product_id": product_id,
            "size": len(data),
        },
    }


# ============================================================
# 获取商品图片列表
# ============================================================

@app.get("/api/images/{product_id}")
async def get_product_images(
    product_id: int
):
    """
    获取某个商品的全部图片。

    例如：

    GET /api/images/8
    """

    if product_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="商品ID无效"
        )

    product_dir = IMAGE_DIR / str(product_id)

    # 商品没有图片目录
    if not product_dir.exists():
        return {
            "code": 200,
            "message": "获取商品图片成功",
            "data": []
        }

    images = []

    # --------------------------------------------------------
    # 遍历图片
    # --------------------------------------------------------

    for path in sorted(product_dir.iterdir()):

        # 只处理文件
        if not path.is_file():
            continue

        # 过滤非图片文件
        if path.suffix.lower() not in ALLOWED_EXTENSIONS:
            continue

        images.append({
            "filename": path.name,
            "image_url": build_image_url(
                product_id,
                path.name
            ),
        })

    return {
        "code": 200,
        "message": "获取商品图片成功",
        "data": images
    }


# ============================================================
# 删除单张图片
# ============================================================

@app.delete("/api/images/{product_id}/{filename}")
async def delete_image(
    product_id: int,
    filename: str
):
    """
    删除某个商品的一张图片。

    例如：

    DELETE
    /api/images/8/xxxxxxxx.png
    """

    if product_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="商品ID无效"
        )

    # --------------------------------------------------------
    # 防止路径穿越
    #
    # 例如：
    # ../../xxx
    # --------------------------------------------------------

    if Path(filename).name != filename:
        raise HTTPException(
            status_code=400,
            detail="非法文件名"
        )

    # --------------------------------------------------------
    # 检查扩展名
    # --------------------------------------------------------

    suffix = Path(filename).suffix.lower()

    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="非法图片格式"
        )

    # --------------------------------------------------------
    # 图片路径
    # --------------------------------------------------------

    file_path = (
        IMAGE_DIR
        / str(product_id)
        / filename
    )

    # --------------------------------------------------------
    # 检查文件
    # --------------------------------------------------------

    if not file_path.exists():
        raise HTTPException(
            status_code=404,
            detail="图片不存在"
        )

    if not file_path.is_file():
        raise HTTPException(
            status_code=400,
            detail="目标不是图片文件"
        )

    # --------------------------------------------------------
    # 删除
    # --------------------------------------------------------

    try:
        file_path.unlink()

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"图片删除失败: {str(e)}"
        )

    # --------------------------------------------------------
    # 如果商品目录已经空了，就删除目录
    # --------------------------------------------------------

    product_dir = IMAGE_DIR / str(product_id)

    if product_dir.exists():

        try:
            remaining_files = list(
                product_dir.iterdir()
            )

            if not remaining_files:
                product_dir.rmdir()

        except OSError:
            pass

    return {
        "code": 200,
        "message": "图片删除成功",
        "data": None
    }


# ============================================================
# 删除商品全部图片
# ============================================================

@app.delete("/api/images/product/{product_id}")
async def delete_product_images(
    product_id: int
):
    """
    删除某个商品的全部图片。

    例如：

    DELETE
    /api/images/product/8
    """

    if product_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="商品ID无效"
        )

    product_dir = IMAGE_DIR / str(product_id)

    # --------------------------------------------------------
    # 如果目录不存在
    # --------------------------------------------------------

    if not product_dir.exists():
        return {
            "code": 200,
            "message": "商品图片删除成功",
            "data": None
        }

    # --------------------------------------------------------
    # 删除目录里的文件
    # --------------------------------------------------------

    try:

        for path in product_dir.iterdir():

            if path.is_file():
                path.unlink()

            elif path.is_dir():
                # 理论上不应该出现子目录
                # 如果出现则不处理，避免误删其他内容
                pass

        # 删除空目录
        try:
            product_dir.rmdir()
        except OSError:
            pass

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"商品图片删除失败: {str(e)}"
        )

    return {
        "code": 200,
        "message": "商品图片删除成功",
        "data": None
    }


# ============================================================
# 根路径
# ============================================================

@app.get("/")
async def root():
    """
    图片服务器根路径。
    """

    return {
        "code": 200,
        "message": "校园二手交易平台图片服务器",
        "data": {
            "status": "running",
            "public_base_url": PUBLIC_BASE_URL,
            "upload_api": "/api/images/upload",
            "health_api": "/health",
        }
    }


# ============================================================
# 启动
# ============================================================

if __name__ == "__main__":
    import uvicorn

    print("=" * 60)
    print("校园二手交易平台图片服务器")
    print("=" * 60)
    print(f"监听地址: {HOST}:{PORT}")
    print(f"图片目录: {IMAGE_DIR}")
    print(f"公网地址: {PUBLIC_BASE_URL}")
    print(f"图片访问: {PUBLIC_BASE_URL}/images/")
    print("=" * 60)

    uvicorn.run(
        app,
        host=HOST,
        port=PORT,
        reload=False
    )